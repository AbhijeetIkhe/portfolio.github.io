<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-29 04:14:26 --> Query error: The user specified as a definer ('hotel'@'localhost') does not exist - Invalid query: CALL todays_service_count('2022-06-29')
ERROR - 2022-06-29 04:14:28 --> Query error: The user specified as a definer ('hotel'@'localhost') does not exist - Invalid query: CALL todays_service_count('2022-06-29')
ERROR - 2022-06-29 04:14:29 --> Query error: The user specified as a definer ('hotel'@'localhost') does not exist - Invalid query: CALL todays_service_count('2022-06-29')
ERROR - 2022-06-29 04:14:36 --> Query error: The user specified as a definer ('hotel'@'localhost') does not exist - Invalid query: CALL todays_service_count('2022-06-29')
ERROR - 2022-06-29 04:14:48 --> Query error: The user specified as a definer ('hotel'@'localhost') does not exist - Invalid query: CALL todays_service_count('2022-06-29')
ERROR - 2022-06-29 04:15:59 --> Query error: The user specified as a definer ('hms_db'@'localhost') does not exist - Invalid query: CALL todays_service_count('2022-06-29')
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Undefined variable $cust D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 60
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Attempt to read property "customer_TCno" on null D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 60
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Undefined variable $cust D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 61
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Attempt to read property "checkin_count" on null D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 61
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Undefined variable $cust D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 62
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Attempt to read property "total_paid" on null D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 62
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Undefined variable $cust D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 213
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Attempt to read property "customer_TCno" on null D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 213
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Undefined variable $cust D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 214
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Attempt to read property "checkin_count" on null D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 214
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Undefined variable $cust D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 215
ERROR - 2022-06-29 04:17:51 --> Severity: Warning --> Attempt to read property "total_paid" on null D:\xampp\htdocs\ci_hms\application\views\welcome_message.php 215
ERROR - 2022-06-29 04:22:41 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\reservation\add.php 37
ERROR - 2022-06-29 04:22:44 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\room-type\list.php 20
ERROR - 2022-06-29 04:26:55 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\room\list.php 20
ERROR - 2022-06-29 04:27:52 --> Severity: error --> Exception: Attempt to assign property "room_type" on null D:\xampp\htdocs\ci_hms\application\models\room_m.php 35
ERROR - 2022-06-29 04:28:07 --> Severity: error --> Exception: Attempt to assign property "room_type" on null D:\xampp\htdocs\ci_hms\application\models\room_m.php 35
ERROR - 2022-06-29 04:28:48 --> Severity: error --> Exception: Attempt to assign property "room_type" on null D:\xampp\htdocs\ci_hms\application\models\room_m.php 35
ERROR - 2022-06-29 04:29:07 --> Severity: error --> Exception: Attempt to assign property "room_type" on null D:\xampp\htdocs\ci_hms\application\models\room_m.php 35
ERROR - 2022-06-29 04:30:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\ci_hms\application\models\room_m.php 35
ERROR - 2022-06-29 04:30:46 --> Severity: error --> Exception: Attempt to assign property "room_type" on null D:\xampp\htdocs\ci_hms\application\models\room_m.php 35
ERROR - 2022-06-29 04:32:02 --> Severity: error --> Exception: Attempt to assign property "min_id" on null D:\xampp\htdocs\ci_hms\application\models\room_m.php 36
ERROR - 2022-06-29 04:34:55 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\restaurant\list.php 25
ERROR - 2022-06-29 04:34:55 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\restaurant\list.php 75
ERROR - 2022-06-29 04:35:32 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\restaurant\list.php 25
ERROR - 2022-06-29 04:38:45 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\medical_service\list.php 25
ERROR - 2022-06-29 04:38:45 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\medical_service\list.php 73
ERROR - 2022-06-29 04:38:56 --> Severity: Warning --> Undefined array key "customer_TCno" D:\xampp\htdocs\ci_hms\application\controllers\customer.php 31
ERROR - 2022-06-29 04:40:11 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2022-06-29 04:40:33 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2022-06-29 04:41:59 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2022-06-29 04:42:13 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2022-06-29 04:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\sport_facility\list.php 25
ERROR - 2022-06-29 04:46:54 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\sport_facility\list.php 73
ERROR - 2022-06-29 04:46:55 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\medical_service\list.php 25
ERROR - 2022-06-29 04:46:55 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\medical_service\list.php 73
ERROR - 2022-06-29 04:46:57 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\medical_service\list.php 25
ERROR - 2022-06-29 04:46:57 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\medical_service\list.php 73
ERROR - 2022-06-29 04:47:34 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\medical_service\list.php 25
ERROR - 2022-06-29 04:49:54 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2022-06-29 04:50:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hms_db`.`do_sport`, CONSTRAINT `do_sport_ibfk_2` FOREIGN KEY (`sportfacility_id`) REFERENCES `sport_facilities` (`sportfacility_id`) ON DELETE CASCADE ON UPDATE CASCADE) - Invalid query: INSERT INTO `do_sport` (`sportfacility_id`, `customer_id`, `employee_id`, `dosport_date`, `dosport_details`, `dosport_price`) VALUES ('1', '3', '1', '2022-06-29', 'Sample Service', '850')
ERROR - 2022-06-29 04:54:17 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\sport_facility\list.php 25
ERROR - 2022-06-29 04:54:17 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\sport_facility\list.php 73
ERROR - 2022-06-29 04:55:03 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\sport_facility\list.php 25
ERROR - 2022-06-29 04:57:52 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\massage_room\list.php 25
ERROR - 2022-06-29 04:57:52 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\massage_room\list.php 73
ERROR - 2022-06-29 04:58:27 --> Severity: Warning --> foreach() argument must be of type array|object, bool given D:\xampp\htdocs\ci_hms\application\views\massage_room\list.php 25
ERROR - 2022-06-29 05:00:53 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 138
ERROR - 2022-06-29 05:00:53 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 138
ERROR - 2022-06-29 05:00:53 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 152
ERROR - 2022-06-29 05:00:53 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 152
ERROR - 2022-06-29 05:00:59 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 138
ERROR - 2022-06-29 05:00:59 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 138
ERROR - 2022-06-29 05:00:59 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 152
ERROR - 2022-06-29 05:00:59 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 152
ERROR - 2022-06-29 05:01:46 --> 404 Page Not Found: Forget/index
ERROR - 2022-06-29 05:37:23 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2022-06-29 05:37:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2022-06-29 05:37:23 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2022-06-29 05:37:23 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2022-06-29 05:37:28 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2022-06-29 05:37:28 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2022-06-29 05:37:28 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2022-06-29 05:37:28 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2022-06-29 05:39:50 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2022-06-29 07:40:04 --> 404 Page Not Found: Room-type/edit
ERROR - 2022-06-29 07:40:33 --> 404 Page Not Found: Room-type/delete
ERROR - 2022-06-29 07:41:53 --> 404 Page Not Found: Room-type/edit
ERROR - 2022-06-29 07:44:19 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2022-06-29 07:44:19 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 97
ERROR - 2022-06-29 07:44:19 --> Severity: Warning --> Undefined variable $next_week_freq D:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2022-06-29 07:44:19 --> Severity: Warning --> Trying to access array offset on value of type null D:\xampp\htdocs\ci_hms\application\views\footer.php 111
ERROR - 2022-06-29 07:44:38 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
ERROR - 2022-06-29 07:45:18 --> Severity: Warning --> Undefined variable $customer_id D:\xampp\htdocs\ci_hms\application\views\reservation\list.php 15
