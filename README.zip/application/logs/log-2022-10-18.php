<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-10-18 08:23:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'hms_db' C:\xampp\htdocs\PHP-ci_hms\system\database\drivers\mysqli\mysqli_driver.php 211
ERROR - 2022-10-18 08:23:31 --> Unable to connect to the database
